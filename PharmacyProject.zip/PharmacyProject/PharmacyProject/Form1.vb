﻿Imports Microsoft.Office.Interop
Imports System.Data
Imports System.Data.OleDb
Imports System.Data.SQLite



Public Class Form1
    Public Shared conn As New SQLiteConnection
    Public Shared dtPatient As New DataTable
    Public Shared dtMedicine As New DataTable

    Dim xlapp As New Excel.Application
    Public Shared dtMorning As New DataTable
    Public Shared dtNoon As New DataTable
    Public Shared dtNight As New DataTable

    Dim morning_med As String
    Dim noon_med As String
    Dim night_med As String



    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        dtMorning.Columns.Add("Name")
        dtMorning.Columns.Add("Quantity")
        dtMorning.Columns.Add("Price", GetType(String))

        dtNoon.Columns.Add("Name")
        dtNoon.Columns.Add("Quantity")
        dtNoon.Columns.Add("Price", GetType(String))

        dtNight.Columns.Add("Name")
        dtNight.Columns.Add("Quantity")
        dtNight.Columns.Add("Price", GetType(String))

        Dim screenWidth As Integer = Screen.PrimaryScreen.Bounds.Width
        Dim screenHeight As Integer = Screen.PrimaryScreen.Bounds.Height

        Me.Size = New Size(screenWidth - 100, screenHeight - 100)
        CenterForm(Me)

        Try
            conn.ConnectionString = "Data Source=" & Environment.CurrentDirectory & "\pharmacy_db.db; Version=3"
        Catch ex As Exception
            MsgBox(ex.Message)
            Exit Sub
        End Try

        getData(dtPatient, "patients", conn)
        getData(dtMedicine, "medicine", conn)
    End Sub


    Sub getData(dt As DataTable, dbtable As String, connecttion As SQLiteConnection)
        Using cmd As New SQLiteCommand
            cmd.CommandText = "Select * From " & dbtable & ""
            cmd.Connection = connecttion
            Dim adapter As New SQLiteDataAdapter(cmd)
            adapter.Fill(dt)
        End Using
    End Sub


    Public Shared Sub CenterForm(ByVal frm As Form, Optional ByVal parent As Form = Nothing)
        '' Note: call this from frm's Load event!
        Dim r As Rectangle
        If parent IsNot Nothing Then
            r = parent.RectangleToScreen(parent.ClientRectangle)
        Else
            r = Screen.FromPoint(frm.Location).WorkingArea
        End If

        Dim x = r.Left + (r.Width - frm.Width) \ 2
        Dim y = r.Top + (r.Height - frm.Height) \ 2
        frm.Location = New Point(x, y)
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim res As DialogResult = MessageBox.Show("Are you sure you want to exit?", "Pharmacy Project", MessageBoxButtons.YesNo)
        If res = vbYes Then
            Application.ExitThread()
        End If

    End Sub

    Private Sub ToolStripButton2_Click(sender As Object, e As EventArgs) Handles ToolStripButton2.Click
        addUser.ShowDialog()
    End Sub

    Private Sub ToolStripButton3_Click(sender As Object, e As EventArgs) Handles ToolStripButton3.Click

        If lblID.Text = "0" Then
            MessageBox.Show("Please select a Patient Record First. Thank you.", "Pharmacy Project")
            Exit Sub
        End If
        editUser.ShowDialog()
    End Sub

    Private Sub ToolStripButton1_Click(sender As Object, e As EventArgs) Handles ToolStripButton1.Click
        Try
            conn.Open()

            Using Command As New SQLiteCommand
                If toolstrip_searchby.Text = "Name" Then
                    Command.CommandText = "select * from patients Where patient_name = @patient_name"
                    Command.Connection = conn
                    Command.Parameters.Clear()
                    Command.Parameters.AddWithValue("@patient_name", toolstrip_search.Text)
                Else
                    Command.CommandText = "select * from patients Where ID = @ID"
                    Command.Connection = conn
                    Command.Parameters.Clear()
                    Command.Parameters.AddWithValue("@ID", toolstrip_search.Text)
                End If

                Dim read As SQLiteDataReader
                read = Command.ExecuteReader
                If read.HasRows = True Then
                    While read.Read
                        Dim spl() As String = Split(read.GetString(1), "/")
                        tboxFName.Text = spl(0)
                        tboxMName.Text = spl(1)
                        tboxLName.Text = spl(2)

                        tboxMobile.Text = read.GetString(2)
                        tboxAge.Text = read.GetString(3)
                        tboxSex.Text = read.GetString(4)
                        tboxBirthday.Text = read.GetString(5)
                        tboxHeight.Text = read.GetString(6)
                        tboxWeight.Text = read.GetString(7)
                        spl = Split(read.GetString(8), "@")
                        tboxEmail.Text = spl(0)
                        tboxEmail2.Text = spl(1)

                        tboxAllergy.Text = read.GetString(read.GetOrdinal("allergy"))
                        tboxMedicalHistory.Text = read.GetString(read.GetOrdinal("medical_history"))
                        tboxFamilyHistory.Text = read.GetString(read.GetOrdinal("family_history"))
                        tboxPresentIllness.Text = read.GetString(read.GetOrdinal("present_illness"))


                        spl = Split(read.GetString(read.GetOrdinal("morning_med")), ",")
                        morning_med = read.GetString(read.GetOrdinal("morning_med"))


                        If dgMorning.Rows.Count > 0 Then
                            dtMorning.Rows.Clear()
                            dgMorning.DataSource = Nothing
                            dgMorning.Columns.Clear()
                            'dgMorning.Columns.RemoveAt(3)
                        End If
                        If dgNoon.Rows.Count > 0 Then
                            dtNoon.Rows.Clear()
                            dgNoon.DataSource = Nothing
                            dgNoon.Columns.Clear()
                        End If
                        If dgNight.Rows.Count > 0 Then
                            dtNight.Rows.Clear()
                            dgNight.DataSource = Nothing
                            dgNight.Columns.Clear()
                        End If

                        Dim c As Integer = 0
                        If spl(0) = "N/A" Then
                        Else
                            If spl.Count > 0 Then
                                For c = 0 To spl.Count - 1
                                    Dim dv As New DataView(dtMedicine)
                                    dv.RowFilter = "med_name = '" & spl(c) & "'"
                                    If dv.Count > 0 Then
                                        dtMorning.Rows.Add(spl(c), 0, dv.Item(0)("med_price").ToString)
                                    Else
                                        dtMorning.Rows.Add(spl(c), 0, "N/A")
                                    End If
                                Next
                                dgMorning.DataSource = dtMorning.DefaultView
                                Dim btn As New DataGridViewButtonColumn()
                                btn.Text = "Add Quantity"
                                btn.HeaderText = "Buy"
                                dgMorning.Columns.Add(btn)
                                dgMorning.Update()
                            End If
                        End If


                        spl = Split(read.GetString(read.GetOrdinal("noon_med")), ",")
                        noon_med = read.GetString(read.GetOrdinal("noon_med"))

                        If spl(0) = "N/A" Then
                        Else
                            If spl.Count > 0 Then
                                For c = 0 To spl.Count - 1
                                    Dim dv As New DataView(dtMedicine)
                                    dv.RowFilter = "med_name = '" & spl(c) & "'"
                                    If dv.Count > 0 Then
                                        dtNoon.Rows.Add(spl(c), 0, dv.Item(0)("med_price").ToString)
                                    Else
                                        dtNoon.Rows.Add(spl(c), 0, "N/A")
                                    End If
                                Next
                                dgNoon.DataSource = dtNoon.DefaultView
                                Dim btn As New DataGridViewButtonColumn()
                                btn.Text = "Add Quantity"
                                btn.HeaderText = "Buy"
                                dgNoon.Columns.Add(btn)
                                dgNoon.Update()
                            End If
                        End If


                        spl = Split(read.GetString(read.GetOrdinal("night_med")), ",")
                        night_med = read.GetString(read.GetOrdinal("night_med"))

                        If spl(0) = "N/A" Then
                        Else
                            If spl.Count > 0 Then
                                For c = 0 To spl.Count - 1
                                    Dim dv As New DataView(dtMedicine)
                                    dv.RowFilter = "med_name = '" & spl(c) & "'"
                                    If dv.Count > 0 Then
                                        dtNight.Rows.Add(spl(c), 0, dv.Item(0)("med_price").ToString)
                                    Else
                                        dtNight.Rows.Add(spl(c), 0, "N/A")
                                    End If
                                Next
                                dgNight.DataSource = dtNight.DefaultView
                                Dim btn As New DataGridViewButtonColumn()
                                btn.Text = "Add Quantity"
                                btn.HeaderText = "Buy"
                                dgNight.Columns.Add(btn)
                                dgNight.Update()
                            End If
                        End If

                        lblID.Text = read.GetValue(0)

                    End While
                End If
                read.Close()

            End Using
            conn.Close()
        Catch ex As Exception
            conn.Close()
            MsgBox(ex.Message)
        End Try
    End Sub

    Dim col As New AutoCompleteStringCollection
    Private Sub toolstrip_search_Enter(sender As Object, e As EventArgs) Handles toolstrip_search.Enter
        If col.Count = 0 Then
            If toolstrip_searchby.Text = "Name" Then
                For i = 0 To dtPatient.Rows.Count - 1
                    col.Add(dtPatient.Rows(i)("patient_name").ToString())
                Next
                toolstrip_search.AutoCompleteSource = AutoCompleteSource.CustomSource
                toolstrip_search.AutoCompleteCustomSource = col
                On Error Resume Next
                toolstrip_search.AutoCompleteMode = AutoCompleteMode.Suggest


            ElseIf toolstrip_searchby.Text = "ID" Then
            Else

                MsgBox("Please select a category first.")
            End If
        Else

        End If
       

    End Sub

    Private Sub OpenPatientsRecordsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OpenPatientsRecordsToolStripMenuItem.Click
        browsePatients.ShowDialog()
    End Sub

    Private Sub PrintDetailsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PrintDetailsToolStripMenuItem.Click
        xlapp = New Excel.Application
        xlapp.Visible = True
        Dim xlwb As Excel.Workbook
        Dim xlws As Excel.Worksheet

        xlwb = xlapp.Workbooks.Open(Environment.CurrentDirectory & "\Templates\patient_info_1.xlsx")
        xlws = xlwb.Worksheets("Template")
        xlws.Copy(xlwb.Sheets(xlwb.Sheets.Count))
        xlwb.ActiveSheet.name = "Print"

        xlwb.ActiveSheet.range("C8").value = tboxFName.Text & " " & tboxMName.Text & " " & tboxLName.Text
        xlwb.ActiveSheet.range("C9").value = tboxBirthday.Text
        xlwb.ActiveSheet.range("G9").value = tboxSex.Text
        xlwb.ActiveSheet.range("D10").value = "'" & tboxMobile.Text
        xlwb.ActiveSheet.range("C11").value = tboxHeight.Text & "CM"
        xlwb.ActiveSheet.range("G11").value = tboxWeight.Text & "KG"
        xlwb.ActiveSheet.range("C12").value = tboxEmail.Text & "@" & tboxEmail2.Text

        xlwb.ActiveSheet.range("D19").value = tboxAllergy.Text
        xlwb.ActiveSheet.range("D25").value = tboxMedicalHistory.Text
        xlwb.ActiveSheet.range("D31").value = tboxFamilyHistory.Text





        xlwb.ActiveSheet.range("W10").value = tboxFName.Text & " " & tboxMName.Text & " " & tboxLName.Text
        xlwb.ActiveSheet.range("U12").value = tboxPresentIllness.Text

        xlwb.ActiveSheet.range("M9").value = morning_med
        xlwb.ActiveSheet.range("M15").value = noon_med
        xlwb.ActiveSheet.range("M21").value = night_med

    End Sub

    Private Sub dgMorning_CellMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles dgMorning.CellMouseClick
        If e.Button = Windows.Forms.MouseButtons.Right Then
            
        ElseIf e.Button = Windows.Forms.MouseButtons.Left Then

            Dim grid = DirectCast(sender, DataGridView)

            If TypeOf grid.Columns(e.ColumnIndex) Is DataGridViewButtonColumn Then
                Dim dgvbc As DataGridViewButtonCell
                If TypeOf grid.Columns(e.ColumnIndex) Is DataGridViewButtonColumn Then
                    dgvbc = Me.dgMorning.Rows(e.RowIndex).Cells(e.ColumnIndex)
                    dtMorning.Rows(e.RowIndex)("Quantity") = CInt(dtMorning.Rows(e.RowIndex)("Quantity").ToString) + 1

                    dgMorning.DataSource = dtMorning
                    dgMorning.Update()
                End If
            End If
        End If

    End Sub

    Private Sub dgNoon_CellMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles dgNoon.CellMouseClick
        If e.Button = Windows.Forms.MouseButtons.Right Then

        ElseIf e.Button = Windows.Forms.MouseButtons.Left Then
            Dim grid = DirectCast(sender, DataGridView)

            If TypeOf grid.Columns(e.ColumnIndex) Is DataGridViewButtonColumn Then
                Dim dgvbc As DataGridViewButtonCell
                dgvbc = Me.dgNoon.Rows(e.RowIndex).Cells(e.ColumnIndex)
                dtNoon.Rows(e.RowIndex)("Quantity") = CInt(dtNoon.Rows(e.RowIndex)("Quantity")) + 1
                dgNoon.DataSource = dtNoon
                dgNoon.Update()
            End If

            End If
    End Sub

    Private Sub dgNight_CellMouseClick(sender As Object, e As DataGridViewCellMouseEventArgs) Handles dgNight.CellMouseClick
        If e.Button = Windows.Forms.MouseButtons.Right Then

        ElseIf e.Button = Windows.Forms.MouseButtons.Left Then
            Dim grid = DirectCast(sender, DataGridView)

            If TypeOf grid.Columns(e.ColumnIndex) Is DataGridViewButtonColumn Then
                Dim dgvbc As DataGridViewButtonCell

                dgvbc = Me.dgNight.Rows(e.RowIndex).Cells(e.ColumnIndex)
                dtNight.Rows(e.RowIndex)("Quantity") = CInt(dtNight.Rows(e.RowIndex)("Quantity")) + 1
                dgNight.DataSource = dtNight
                dgNight.Update()
            End If
        End If

    End Sub

    Private Sub BrowseMedicineToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles BrowseMedicineToolStripMenuItem.Click
        browseMedicine.ShowDialog()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click


        Dim itemCount As Integer = 0

        For x As Integer = 1 To dgMorning.Rows.Count
            itemCount += 1
        Next
        For x As Integer = 1 To dgNight.Rows.Count
            itemCount += 1
        Next
        For x As Integer = 1 To dgNoon.Rows.Count
            itemCount += 1
        Next

        xlapp = New Excel.Application
        xlapp.Visible = True
        Dim xlwb As Excel.Workbook
        Dim xlws As Excel.Worksheet

        xlwb = xlapp.Workbooks.Open(Environment.CurrentDirectory & "\Templates\patient_info_1.xlsx")
        xlws = xlwb.Worksheets("ReceiptTemplate")
        xlws.Copy(xlwb.Sheets(xlwb.Sheets.Count))
        xlwb.ActiveSheet.name = "PrintReceipt"

        xlwb.ActiveSheet.range("C8").value = tboxFName.Text & " " & tboxMName.Text & " " & tboxLName.Text
        With xlwb.ActiveSheet
            For i As Integer = 12 To 12 + itemCount - 1
                '~~> Set your range
                Dim rng As Excel.Range
                rng = .Rows(i & ":" & i)

                '~~> Copy the range
                rng.Copy()

                '~~> Insert the range
                rng.Offset(1).Insert(Shift:=Excel.XlDirection.xlDown)
                '~~> Clear the clipboard. More importantly remove the
                '~~> ant like borders
            Next
        End With


        Dim lastrow As Integer = 0


        For row As Integer = 0 To dgMorning.Rows.Count - 1
            With xlwb.ActiveSheet
                lastrow = .Range("B" & .Rows.Count).End(Excel.XlDirection.xlUp).Row()
            End With
            If dgMorning.Rows(row).Cells(0).Value = "" Then
                xlwb.ActiveSheet.range("B" & lastrow + 1).value = dgMorning.Rows(row).Cells(1).Value
                xlwb.ActiveSheet.range("E" & lastrow + 1).value = dgMorning.Rows(row).Cells(2).Value
                xlwb.ActiveSheet.range("F" & lastrow + 1).value = dgMorning.Rows(row).Cells(3).Value
            Else
                xlwb.ActiveSheet.range("B" & lastrow + 1).value = dgMorning.Rows(row).Cells(0).Value
                xlwb.ActiveSheet.range("E" & lastrow + 1).value = dgMorning.Rows(row).Cells(1).Value
                xlwb.ActiveSheet.range("F" & lastrow + 1).value = dgMorning.Rows(row).Cells(2).Value

            End If
        Next

        For row As Integer = 0 To dgNoon.Rows.Count - 1
            With xlwb.ActiveSheet
                lastrow = .Range("B" & .Rows.Count).End(Excel.XlDirection.xlUp).Row()
            End With
            If dgNoon.Rows(row).Cells(0).Value = "" Then
                xlwb.ActiveSheet.range("B" & lastrow + 1).value = dgNoon.Rows(row).Cells(1).Value
                xlwb.ActiveSheet.range("E" & lastrow + 1).value = dgNoon.Rows(row).Cells(2).Value
                xlwb.ActiveSheet.range("F" & lastrow + 1).value = dgNoon.Rows(row).Cells(3).Value
            Else
                xlwb.ActiveSheet.range("B" & lastrow + 1).value = dgNoon.Rows(row).Cells(0).Value
                xlwb.ActiveSheet.range("E" & lastrow + 1).value = dgNoon.Rows(row).Cells(1).Value
                xlwb.ActiveSheet.range("F" & lastrow + 1).value = dgNoon.Rows(row).Cells(2).Value


            End If
        Next

        For row As Integer = 0 To dgNight.Rows.Count - 1
            With xlwb.ActiveSheet
                lastrow = .Range("B" & .Rows.Count).End(Excel.XlDirection.xlUp).Row()
            End With
            If dgNight.Rows(row).Cells(0).Value = "" Then
                xlwb.ActiveSheet.range("B" & lastrow + 1).value = dgNight.Rows(row).Cells(1).Value
                xlwb.ActiveSheet.range("E" & lastrow + 1).value = dgNight.Rows(row).Cells(2).Value
                xlwb.ActiveSheet.range("F" & lastrow + 1).value = dgNight.Rows(row).Cells(3).Value
            Else
                xlwb.ActiveSheet.range("B" & lastrow + 1).value = dgNight.Rows(row).Cells(0).Value
                xlwb.ActiveSheet.range("E" & lastrow + 1).value = dgNight.Rows(row).Cells(1).Value
                xlwb.ActiveSheet.range("F" & lastrow + 1).value = dgNight.Rows(row).Cells(2).Value
            End If
        Next




        'For x As Integer = 0 To dtMorning.Rows.Count - 1
        '    MsgBox(dtMorning.Rows(x)("Quantity").ToString & dtMorning.Rows(x)("Name").ToString)
        '    Using updateComm As New SQLiteCommand("Update medicine SET ('med_quantity')  = DIFF(med_quantity - " & dtMorning.Rows(x)("Quantity").ToString & ") " &
        '                                                              " Where 'med_name' = @med_name;", conn)
        '        Try
        '            conn.Open()
        '            updateComm.Parameters.Clear()
        '            'updateComm.Parameters.AddWithValue("@med_quantity", dtMorning.Rows(x)("Quantity").ToString)
        '            updateComm.Parameters.AddWithValue("@med_name", dtMorning.Rows(x)("Name").ToString)
        '            updateComm.ExecuteNonQuery()

        '            conn.Close()
        '        Catch ex As Exception
        '            Form1.conn.Close()
        '            MsgBox(ex.Message)
        '        Finally
        '        End Try
        '    End Using
        'Next

    End Sub

    Private Sub ToolStripButton4_Click(sender As Object, e As EventArgs) Handles toolstripRefresh.Click
        If lblID.Text = "0" Then
            MessageBox.Show("Please search a patient first.")
            Exit Sub
        End If
        Try
            conn.Open()

            Using Command As New SQLiteCommand

                Command.CommandText = "select * from patients Where ID = @ID"
                Command.Connection = conn
                Command.Parameters.Clear()
                Command.Parameters.AddWithValue("@ID", lblID.Text)


                Dim read As SQLiteDataReader
                read = Command.ExecuteReader
                If read.HasRows = True Then
                    While read.Read
                        Dim spl() As String = Split(read.GetString(1), "/")
                        tboxFName.Text = spl(0)
                        tboxMName.Text = spl(1)
                        tboxLName.Text = spl(2)

                        tboxMobile.Text = read.GetString(2)
                        tboxAge.Text = read.GetString(3)
                        tboxSex.Text = read.GetString(4)
                        tboxBirthday.Text = read.GetString(5)
                        tboxHeight.Text = read.GetString(6)
                        tboxWeight.Text = read.GetString(7)
                        spl = Split(read.GetString(8), "@")
                        tboxEmail.Text = spl(0)
                        tboxEmail2.Text = spl(1)

                        tboxAllergy.Text = read.GetString(read.GetOrdinal("allergy"))
                        tboxMedicalHistory.Text = read.GetString(read.GetOrdinal("medical_history"))
                        tboxFamilyHistory.Text = read.GetString(read.GetOrdinal("family_history"))
                        tboxPresentIllness.Text = read.GetString(read.GetOrdinal("present_illness"))


                        spl = Split(read.GetString(read.GetOrdinal("morning_med")), ",")

                        If dgMorning.Rows.Count > 0 Then
                            dtMorning.Rows.Clear()
                            dgMorning.DataSource = Nothing
                            dgMorning.Columns.Clear()
                            'dgMorning.Columns.RemoveAt(3)
                        End If
                        If dgNoon.Rows.Count > 0 Then
                            dtNoon.Rows.Clear()
                            dgNoon.DataSource = Nothing
                            dgNoon.Columns.Clear()
                        End If
                        If dgNight.Rows.Count > 0 Then
                            dtNight.Rows.Clear()
                            dgNight.DataSource = Nothing
                            dgNight.Columns.Clear()
                        End If

                        Dim c As Integer = 0
                        If spl(0) = "N/A" Then
                        Else
                            If spl.Count > 0 Then
                                For c = 0 To spl.Count - 1
                                    Dim dv As New DataView(dtMedicine)
                                    dv.RowFilter = "med_name = '" & spl(c) & "'"
                                    If dv.Count > 0 Then
                                        dtMorning.Rows.Add(spl(c), 0, dv.Item(0)("med_price").ToString)
                                    Else
                                        dtMorning.Rows.Add(spl(c), 0, "N/A")
                                    End If
                                Next
                                dgMorning.DataSource = dtMorning.DefaultView
                                Dim btn As New DataGridViewButtonColumn()
                                btn.Text = "Add Quantity"
                                btn.HeaderText = "Buy"
                                dgMorning.Columns.Add(btn)
                                dgMorning.Update()
                            End If
                        End If


                        spl = Split(read.GetString(read.GetOrdinal("noon_med")), ",")


                        If spl(0) = "N/A" Then
                        Else
                            If spl.Count > 0 Then
                                For c = 0 To spl.Count - 1
                                    Dim dv As New DataView(dtMedicine)
                                    dv.RowFilter = "med_name = '" & spl(c) & "'"
                                    If dv.Count > 0 Then
                                        dtNoon.Rows.Add(spl(c), 0, dv.Item(0)("med_price").ToString)
                                    Else
                                        dtNoon.Rows.Add(spl(c), 0, "N/A")
                                    End If
                                Next
                                dgNoon.DataSource = dtNoon.DefaultView
                                Dim btn As New DataGridViewButtonColumn()
                                btn.Text = "Add Quantity"
                                btn.HeaderText = "Buy"
                                dgNoon.Columns.Add(btn)
                                dgNoon.Update()
                            End If
                        End If


                        spl = Split(read.GetString(read.GetOrdinal("night_med")), ",")


                        If spl(0) = "N/A" Then
                        Else
                            If spl.Count > 0 Then
                                For c = 0 To spl.Count - 1
                                    Dim dv As New DataView(dtMedicine)
                                    dv.RowFilter = "med_name = '" & spl(c) & "'"
                                    If dv.Count > 0 Then
                                        dtNight.Rows.Add(spl(c), 0, dv.Item(0)("med_price").ToString)
                                    Else
                                        dtNight.Rows.Add(spl(c), 0, "N/A")
                                    End If
                                Next
                                dgNight.DataSource = dtNight.DefaultView
                                Dim btn As New DataGridViewButtonColumn()
                                btn.Text = "Add Quantity"
                                btn.HeaderText = "Buy"
                                dgNight.Columns.Add(btn)
                                dgNight.Update()
                            End If
                        End If

                        lblID.Text = read.GetValue(0)

                    End While
                End If
                read.Close()

            End Using
            conn.Close()
        Catch ex As Exception
            conn.Close()
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        ToolStripButton4_Click(sender, e)
    End Sub

End Class
