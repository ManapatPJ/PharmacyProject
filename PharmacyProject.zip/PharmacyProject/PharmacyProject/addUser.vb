﻿
Imports System.Data
Imports System.Data.OleDb
Imports System.Data.SQLite


Public Class addUser

    Private Sub addUsers_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim screenWidth As Integer = Screen.PrimaryScreen.Bounds.Width
        Dim screenHeight As Integer = Screen.PrimaryScreen.Bounds.Height

        Me.Size = New Size(screenWidth - 100, screenHeight - 100)
        CenterForm(Me)
    End Sub

    Public Shared Sub CenterForm(ByVal frm As Form, Optional ByVal parent As Form = Nothing)
        '' Note: call this from frm's Load event!
        Dim r As Rectangle
        If parent IsNot Nothing Then
            r = parent.RectangleToScreen(parent.ClientRectangle)
        Else
            r = Screen.FromPoint(frm.Location).WorkingArea
        End If

        Dim x = r.Left + (r.Width - frm.Width) \ 2
        Dim y = r.Top + (r.Height - frm.Height) \ 2
        frm.Location = New Point(x, y)
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub toolstrip_add_Click(sender As Object, e As EventArgs) Handles toolstrip_add.Click
        If tboxLName.Text = "" Or tboxFName.Text = "" Or tboxMName.Text = "" Or tboxAge.Text = "" Or tboxBirthday.Text = "" Or tboxEmail.Text = "" Or tboxEmail2.Text = "" And tboxSex.Text = "" Then
            MessageBox.Show("Please input all necessary informations.")
            Exit Sub
        End If
        InsertPatient()
    End Sub


    Sub InsertPatient()
        Using updateComm As New SQLiteCommand("Insert Into patients (patient_name, mobile, age, sex, birthday, height, weight, email, morning_med, noon_med, night_med, allergy, medical_history, family_history, present_illness) Values (@patient_name, @mobile, @age, @sex, @birthday, @height, @weight, @email, @morning_med, @noon_med, @night_med, @allergy, @medical_history, @family_history, @present_illness)", Form1.conn)
            Try
                Form1.conn.Open()
                updateComm.Parameters.Clear()
                updateComm.Parameters.AddWithValue("@patient_name", tboxFName.Text & "/" & tboxMName.Text & "/" & tboxLName.Text)
                updateComm.Parameters.AddWithValue("@mobile", tboxMobile.Text)
                updateComm.Parameters.AddWithValue("@age", tboxAge.Text)
                updateComm.Parameters.AddWithValue("@sex", tboxSex.Text)
                updateComm.Parameters.AddWithValue("@birthday", Format(tboxBirthday.Value, "MM/dd/yyyy"))
                updateComm.Parameters.AddWithValue("@height", tboxHeight.Text)
                updateComm.Parameters.AddWithValue("@weight", tboxWeight.Text)
                updateComm.Parameters.AddWithValue("@email", tboxEmail.Text & "@" & tboxEmail2.Text)

                updateComm.Parameters.AddWithValue("@morning_med", tboxMorning.Text)
                updateComm.Parameters.AddWithValue("@noon_med", tboxNoon.Text)
                updateComm.Parameters.AddWithValue("@night_med", tboxNight.Text)

                updateComm.Parameters.AddWithValue("@allergy", tboxAllergy.Text)
                updateComm.Parameters.AddWithValue("@medical_history", tboxMedicalHistory.Text)
                updateComm.Parameters.AddWithValue("@family_history", tboxFamilyHistory.Text)
                updateComm.Parameters.AddWithValue("@present_illness", tboxPresentIllness.Text)
                updateComm.ExecuteNonQuery()
                Form1.conn.Close()


                cleartext(pnlInfo)

                MessageBox.Show("Patient Record Successfully Created.")
            Catch ex As Exception
                Form1.conn.Close()
                MsgBox(ex.Message)
            Finally
                getData(Form1.dtPatient, "patients", Form1.conn)
            End Try
        End Using
    End Sub

    Sub numOnly(ByVal e As System.Windows.Forms.KeyPressEventArgs)
        If Asc(e.KeyChar) <> 8 Then
            If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then
                e.Handled = True
            End If
        End If
    End Sub

    Sub getData(dt As DataTable, dbtable As String, connecttion As SQLiteConnection)
        Using cmd As New SQLiteCommand
            cmd.CommandText = "Select * From " & dbtable & ""
            cmd.Connection = connecttion
            Dim adapter As New SQLiteDataAdapter(cmd)
            adapter.Fill(dt)
        End Using
    End Sub

    Sub cleartext(pnl As Panel)
        For Each txt In pnl.Controls.OfType(Of TextBox)()
            txt.Text = ""
        Next
    End Sub

    Private Sub tboxMobile_KeyPress(sender As Object, e As KeyPressEventArgs) Handles tboxMobile.KeyPress
        numOnly(e)
    End Sub

    Private Sub tboxAge_KeyPress(sender As Object, e As KeyPressEventArgs) Handles tboxAge.KeyPress
        numOnly(e)
    End Sub

    Private Sub tboxHeight_KeyPress(sender As Object, e As KeyPressEventArgs) Handles tboxHeight.KeyPress
        numOnly(e)
    End Sub

    Private Sub tboxWeight_KeyPress(sender As Object, e As KeyPressEventArgs) Handles tboxWeight.KeyPress
        numOnly(e)
    End Sub

    Private Sub DateTimePicker1_ValueChanged(sender As Object, e As EventArgs) Handles tboxBirthday.ValueChanged

    End Sub
End Class
