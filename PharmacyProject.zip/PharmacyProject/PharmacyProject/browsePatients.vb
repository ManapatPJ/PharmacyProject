﻿
Imports System.Data
Imports System.Data.OleDb
Imports System.Data.SQLite


Public Class browsePatients
    Public Shared dtPatient As New DataTable
    Private Sub browsePatients_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        dtPatient.Rows.Clear()
        getData(dtPatient, "patients", Form1.conn)

        DataGridView1.DataSource = dtPatient.DefaultView
        DataGridView1.Columns(1).Frozen = True
        DataGridView1.Update()
    End Sub

    Sub getData(dt As DataTable, dbtable As String, connecttion As SQLiteConnection)
        Using cmd As New SQLiteCommand
            cmd.CommandText = "Select ID, patient_name as Name, mobile as 'Contact Number', age as Age, sex as Gender,birthday as 'Birth Date', height as Height, weight as Weight, email as 'E-Mail', morning_med as 'Morning Medication', noon_med as 'Noon Medication', night_med as 'Night Medication', allergy as 'Allergy', medical_history as 'Medical History', family_history as 'Family History', present_illness as 'Present Illness' From " & dbtable & ""
            cmd.Connection = connecttion
            Dim adapter As New SQLiteDataAdapter(cmd)
            adapter.Fill(dt)
        End Using
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Using updateComm As New SQLiteCommand("Delete from patients where ID = @ID", Form1.conn)
            Try
                Form1.conn.Open()
                updateComm.Parameters.Clear()
                MessageBox.Show(DataGridView1.SelectedRows(0).Cells(0).Value.ToString)
                updateComm.Parameters.AddWithValue("@ID", DataGridView1.SelectedRows(0).Cells(0).Value.ToString)

                updateComm.ExecuteNonQuery()
                Form1.conn.Close()
                MessageBox.Show("Patient Record Successfully Created.")
            Catch ex As Exception
                Form1.conn.Close()
                MsgBox(ex.Message)
            Finally
                getData(Form1.dtPatient, "patients", Form1.conn)
                DataGridView1.DataSource = dtPatient.DefaultView
                DataGridView1.Columns(1).Frozen = True
                DataGridView1.Update()
            End Try
        End Using
    End Sub
End Class