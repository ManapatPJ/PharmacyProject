﻿
Imports System.Data
Imports System.Data.OleDb
Imports System.Data.SQLite


Public Class editUser

    Private Sub addUsers_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim screenWidth As Integer = Screen.PrimaryScreen.Bounds.Width
        Dim screenHeight As Integer = Screen.PrimaryScreen.Bounds.Height

        Me.Size = New Size(screenWidth - 100, screenHeight - 100)
        CenterForm(Me)



        'tboxFName.Text = Form1.tboxFName.Text
        'tboxMName.Text = Form1.tboxMName.Text
        'tboxLName.Text = Form1.tboxLName.Text
        'tboxAge.Text = Form1.tboxAge.Text
        'tboxMobile.Text = Form1.tboxMobile.Text
        'tboxBirthday.Text = Form1.tboxBirthday.Text
        'tboxHeight.Text = Form1.tboxHeight.Text
        'tboxWeight.Text = Form1.tboxWeight.Text
        'tboxSex.Text = Form1.tboxSex.Text
        'tboxEmail.Text = Form1.tboxEmail.Text
        'tboxEmail2.Text = Form1.tboxEmail2.Text


        'tboxAllergy.Text = Form1.tboxAllergy.Text
        'tboxFamilyHistory.Text = Form1.tboxFamilyHistory.Text
        'tboxMedicalHistory.Text = Form1.tboxMedicalHistory.Text
        'tboxPresentIllness.Text = Form1.tboxPresentIllness.Text
        lblID.Text = Form1.lblID.Text
        data()
    End Sub

    Sub data()
        Try
            Form1.conn.Open()

            Using Command As New SQLiteCommand
                
                Command.CommandText = "select * from patients Where ID = @ID"
                Command.Connection = Form1.conn
                Command.Parameters.Clear()
                Command.Parameters.AddWithValue("@ID", lblID.Text)


                Dim read As SQLiteDataReader
                read = Command.ExecuteReader
                If read.HasRows = True Then
                    While read.Read
                        Dim spl() As String = Split(read.GetString(1), "/")
                        tboxFName.Text = spl(0)
                        tboxMName.Text = spl(1)
                        tboxLName.Text = spl(2)

                        tboxMobile.Text = read.GetString(2)
                        tboxAge.Text = read.GetString(3)
                        tboxSex.Text = read.GetString(4)
                        tboxBirthday.Text = read.GetString(5)
                        tboxHeight.Text = read.GetString(6)
                        tboxWeight.Text = read.GetString(7)
                        spl = Split(read.GetString(8), "@")
                        tboxEmail.Text = spl(0)
                        tboxEmail2.Text = spl(1)

                        tboxAllergy.Text = read.GetString(read.GetOrdinal("allergy"))
                        tboxMedicalHistory.Text = read.GetString(read.GetOrdinal("medical_history"))
                        tboxFamilyHistory.Text = read.GetString(read.GetOrdinal("family_history"))
                        tboxPresentIllness.Text = read.GetString(read.GetOrdinal("present_illness"))


                        tboxMorning.Text = read.GetString(read.GetOrdinal("morning_med"))
                        tboxNoon.Text = read.GetString(read.GetOrdinal("noon_med"))
                        tboxNight.Text = read.GetString(read.GetOrdinal("night_med"))


                    End While
                End If
                read.Close()

            End Using
            Form1.conn.Close()
        Catch ex As Exception
            Form1.conn.Close()
            MsgBox(ex.Message)
        End Try
    End Sub

    Public Shared Sub CenterForm(ByVal frm As Form, Optional ByVal parent As Form = Nothing)
        '' Note: call this from frm's Load event!
        Dim r As Rectangle
        If parent IsNot Nothing Then
            r = parent.RectangleToScreen(parent.ClientRectangle)
        Else
            r = Screen.FromPoint(frm.Location).WorkingArea
        End If

        Dim x = r.Left + (r.Width - frm.Width) \ 2
        Dim y = r.Top + (r.Height - frm.Height) \ 2
        frm.Location = New Point(x, y)
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Me.Close()


    End Sub

    Private Sub OpenPatientsRecordsToolStripMenuItem_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Panel1_Paint(sender As Object, e As PaintEventArgs) Handles Panel1.Paint

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If tboxLName.Text = "" Or tboxFName.Text = "" Or tboxMName.Text = "" Or tboxAge.Text = "" Or tboxBirthday.Text = "" Or tboxEmail.Text = "" Or tboxEmail2.Text = "" And tboxSex.Text = "" Then
            MessageBox.Show("Please input all necessary informations.")
            Exit Sub
        End If
        Using updateComm As New SQLiteCommand("Update patients SET ('patient_name') = (@patient_name), " &
                                                                  "('mobile') = (@mobile)," &
                                                                  "('age') = (@age)," &
                                                                  "('sex') = (@sex)," &
                                                                  "('birthday') = (@birthday)," &
                                                                  "('height') = (@height)," &
                                                                  "('weight') = (@weight)," &
                                                                  "('email') = (@email)," &
                                                                  "('allergy') = (@allergy)," &
                                                                  "('medical_history') = (@medical_history)," &
                                                                  "('family_history') = (@family_history)," &
                                                                  "('present_illness') = (@present_illness)" &
                                                                  " Where ID = @ID;", Form1.conn)
            Try
                Form1.conn.Open()
                updateComm.Parameters.Clear()
                updateComm.Parameters.AddWithValue("@patient_name", tboxFName.Text & "/" & tboxMName.Text & "/" & tboxLName.Text)
                updateComm.Parameters.AddWithValue("@mobile", tboxMobile.Text)
                updateComm.Parameters.AddWithValue("@age", tboxAge.Text)
                updateComm.Parameters.AddWithValue("@sex", tboxSex.Text)
                updateComm.Parameters.AddWithValue("@birthday", tboxBirthday.Text)
                updateComm.Parameters.AddWithValue("@height", tboxHeight.Text)
                updateComm.Parameters.AddWithValue("@weight", tboxWeight.Text)
                updateComm.Parameters.AddWithValue("@email", tboxEmail.Text & "@" & tboxEmail2.Text)
                updateComm.Parameters.AddWithValue("@allergy", tboxAllergy.Text)
                updateComm.Parameters.AddWithValue("@medical_history", tboxMedicalHistory.Text)
                updateComm.Parameters.AddWithValue("@family_history", tboxFamilyHistory.Text)
                updateComm.Parameters.AddWithValue("@present_illness", tboxPresentIllness.Text)
                updateComm.Parameters.AddWithValue("@ID", lblID.Text)
                updateComm.ExecuteNonQuery()

                Form1.conn.Close()
                cleartext(pnlinfo)
                cleartext(pnlMedical)
            Catch ex As Exception
                Form1.conn.Close()
                MsgBox(ex.Message)
            Finally

                MessageBox.Show("Patient Record edited successfully. Click 'Search' Again to see the update.")


            End Try
        End Using
     
    End Sub

    Sub cleartext(pnl As Panel)
        For Each txt In pnl.Controls.OfType(Of TextBox)()
            txt.Text = ""
        Next
        lblID.Text = "0"

        tboxAllergy.Clear()
        tboxFamilyHistory.Clear()
        tboxMedicalHistory.Clear()
        tboxPresentIllness.Clear()
    End Sub

    Private Sub tboxMorning_MouseClick(sender As Object, e As MouseEventArgs) Handles tboxMorning.MouseClick

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

        Using updateComm As New SQLiteCommand("Update patients SET ('morning_med') = (@morning_med), " &
                                                                             "('noon_med') = (@noon_med)," &
                                                                             "('night_med') = (@night_med)" &
                                                                             " Where ID = @ID;", Form1.conn)
            Try
                Form1.conn.Open()
                updateComm.Parameters.Clear()

                updateComm.Parameters.AddWithValue("@morning_med", tboxMorning.Text)
                updateComm.Parameters.AddWithValue("@noon_med", tboxNoon.Text)
                updateComm.Parameters.AddWithValue("@night_med", tboxNight.Text)
                updateComm.Parameters.AddWithValue("@ID", lblID.Text)
                updateComm.ExecuteNonQuery()

                Form1.conn.Close()
                cleartext(pnlinfo)
                cleartext(pnlMedical)
            Catch ex As Exception
                Form1.conn.Close()
                MsgBox(ex.Message)
            Finally
                tboxMorning.Clear()
                tboxNoon.Clear()
                tboxNight.Clear()

            End Try
        End Using

        Button2_Click(sender, e)
        Me.Close()
    End Sub

    Sub numOnly(ByVal e As System.Windows.Forms.KeyPressEventArgs)
        If Asc(e.KeyChar) <> 8 Then
            If Asc(e.KeyChar) < 48 Or Asc(e.KeyChar) > 57 Then
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub tboxAge_KeyPress(sender As Object, e As KeyPressEventArgs) Handles tboxAge.KeyPress
        numOnly(e)
    End Sub

    Private Sub tboxMobile_KeyPress(sender As Object, e As KeyPressEventArgs) Handles tboxMobile.KeyPress
        numOnly(e)
    End Sub

    Private Sub tboxHeight_KeyPress(sender As Object, e As KeyPressEventArgs) Handles tboxHeight.KeyPress
        numOnly(e)
    End Sub

    Private Sub tboxWeight_KeyPress(sender As Object, e As KeyPressEventArgs) Handles tboxWeight.KeyPress
        numOnly(e)
    End Sub
End Class
